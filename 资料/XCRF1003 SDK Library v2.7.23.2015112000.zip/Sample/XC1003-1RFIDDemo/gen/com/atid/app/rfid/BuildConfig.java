/** Automatically generated file. DO NOT MODIFY */
package com.atid.app.rfid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}